-- Settings for EssentialMode
TriggerEvent("es:setDefaultSettings", {
    pvpEnabled = true,
    debugInformation = false,
    startingCash = 100,
    nativeMoneySystem = true
})